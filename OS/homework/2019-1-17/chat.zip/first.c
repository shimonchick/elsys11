#include <stdio.h> 
#include <string.h> 
#include <fcntl.h> 
#include <sys/stat.h> 
#include <sys/types.h> 
#include <unistd.h> 
#include <stdlib.h>

#define true 1

void write_fifo(const char* fifo){
    int fd = open(fifo, O_WRONLY);
    if(fd < 0){
        perror("open");
        exit(1);
    }
    char arr[100];
    if(fgets(arr, 100, stdin) == 0){
        //printf("no input");
        //close(fifo);
        exit(0);
    }
    write(fd, arr, strlen(arr) + 1);
    close(fd);
}
void read_fifo(const char* fifo){
    int fd = open(fifo, O_RDONLY);
    if(fd < 0){
        perror("open");
        exit(1);
    }
    char arr[100];
    ssize_t bytes_read = read(fd, arr, sizeof(arr));
    printf("User2: %s", arr);

}
int main(){
    char* fifo = "chat";
    char* fifo2 = "chat2";
    mkfifo(fifo, 0666);
    while(true){
        write_fifo(fifo);
        read_fifo(fifo2);
    }

}
