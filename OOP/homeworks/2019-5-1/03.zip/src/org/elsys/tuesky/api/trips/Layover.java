package org.elsys.tuesky.api.trips;

public interface Layover extends TripUnit {

}
