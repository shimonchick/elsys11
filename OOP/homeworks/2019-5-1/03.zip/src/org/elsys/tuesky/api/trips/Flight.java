package org.elsys.tuesky.api.trips;

public interface Flight extends TripUnit {

    String getOrigin();

    String getDestination();
}
