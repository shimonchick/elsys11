package com.company;

public class Main {

    public static void main(String[] args) {
        System.out.printf("Hello Java world from Mr/s ");
        for (String arg : args) {
            System.out.printf("%s ", arg);
        }
        System.out.println("");
    }
}
